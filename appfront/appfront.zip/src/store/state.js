const state = {
    userInfo: []
}
  
export default state