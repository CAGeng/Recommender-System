const getters = {
    getUserInfo: state => state.userInfo   
}
  
export default getters